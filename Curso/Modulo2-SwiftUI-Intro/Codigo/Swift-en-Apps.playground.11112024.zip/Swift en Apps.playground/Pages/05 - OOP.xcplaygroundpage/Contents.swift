import Foundation

/*:
# Ejemplo de Herencia en Orientación a Objetos

La **herencia** es un principio fundamental en la programación orientada a objetos (POO). Permite que una clase herede propiedades y métodos de otra, facilitando la reutilización del código y la extensión de funcionalidades. Sin embargo, este enfoque presenta ciertos problemas y limitaciones, especialmente cuando se compara con otras técnicas como la orientación a protocolos, que es más flexible y modular.

### Problemas con la Herencia
1. **Herencia Forzada**: En la herencia, una subclase hereda todas las propiedades y métodos de la clase base, incluso si no todos son relevantes para la subclase. Esto puede llevar a que las subclases tengan comportamientos o propiedades que no necesitan, lo cual puede ser una carga innecesaria y complicar la estructura del código.
2. **Falta de Flexibilidad**: Una clase solo puede heredar de una única clase (herencia simple). Esto limita la capacidad de una subclase para reutilizar funcionalidades de varias fuentes. En cambio, los protocolos permiten adoptar varios comportamientos diferentes sin tener que heredar una jerarquía compleja.
3. **Acoplamiento Fuerte**: Con la herencia, existe un acoplamiento fuerte entre la clase base y sus subclases, lo que hace que los cambios en la clase base puedan impactar de manera significativa en todas las subclases. Esto dificulta la modularización y la extensibilidad.
4. **Complejidad Creciente**: A medida que las jerarquías de herencia crecen, el sistema se vuelve más difícil de mantener y entender. Esto puede conducir a errores y al "fragile base class problem", donde las modificaciones en una clase base pueden causar problemas inesperados en las subclases.

En este ejemplo, veremos una estructura básica de clases heredadas que muestra algunas de estas limitaciones.
*/

//: ## Ejemplo de Clases con Herencia
//: `Personaje` es una clase base que tiene una propiedad `nombre`.
class Personaje {
    var nombre: String
    
    init(nombre: String) {
        self.nombre = nombre
    }
}

//: `PersonajeHablador` hereda de `Personaje` y agrega una nueva propiedad `dialogo`.
class PersonajeHablador: Personaje {
    var dialogo: String
    
    init(nombre: String, dialogo: String) {
        self.dialogo = dialogo
        super.init(nombre: nombre)
    }
}

//: `PersonajeAtacanteHablador` hereda de `PersonajeHablador` y agrega una propiedad `ataque`.
class PersonajeAtacanteHablador: PersonajeHablador {
    var ataque: Int
    
    init(nombre: String, dialogo: String, ataque: Int) {
        self.ataque = ataque
        super.init(nombre: nombre, dialogo: dialogo)
    }
}

/*:
# Limitaciones de este Enfoque

En la estructura mostrada arriba, podemos observar los problemas de la herencia:

- **Herencia Forzada**: `PersonajeAtacanteHablador` tiene que heredar tanto la propiedad `nombre` como la propiedad `dialogo`, incluso si en alguna situación particular no desea hablar. Estamos obligados a heredar ambas propiedades, lo cual puede ser una limitación si nuestro personaje sólo necesita la capacidad de atacar.

- **Acoplamiento Fuerte**: Si decidiéramos cambiar cómo funciona la propiedad `dialogo` en `PersonajeHablador`, esos cambios afectarían automáticamente a `PersonajeAtacanteHablador`, ya que depende de la implementación de la clase base.

- **Dificultad para Modularizar**: En lugar de crear múltiples combinaciones de habilidades mediante clases base y subclases, terminamos con una jerarquía profunda y difícil de gestionar. Para cada combinación de habilidades (por ejemplo, hablar, atacar, defender), tendríamos que crear una nueva clase que herede de otra, lo cual lleva a una combinatoria de clases compleja.

En el próximo ejemplo, veremos cómo estos problemas se pueden solucionar usando la **orientación a protocolos**, un enfoque más flexible y modular que permite combinar comportamientos sin las restricciones de una jerarquía de herencia fija.
*/
