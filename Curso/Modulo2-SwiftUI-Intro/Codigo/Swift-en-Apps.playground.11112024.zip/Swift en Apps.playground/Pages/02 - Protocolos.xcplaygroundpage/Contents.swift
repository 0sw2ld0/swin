import SwiftUI

/*:
# Protocolos en Swift

En Swift, un **protocolo** es una colección de propiedades y métodos que define un comportamiento o una capacidad. Podemos imaginar un protocolo como un **contrato** que especifica ciertos requisitos que cualquier tipo (clase, estructura o enumeración) debe cumplir si adopta dicho protocolo. Los protocolos permiten **programar orientado a interfaces**, lo que significa que podemos definir funcionalidades sin preocuparnos por la implementación subyacente. Esto hace que el código sea más flexible y reutilizable.

### Ejemplo de la vida real
Podemos pensar en un protocolo como un conjunto de reglas para una licencia de conducir. Para obtener una licencia, un conductor debe cumplir ciertos requisitos, como aprobar un examen teórico y uno práctico. Cualquier persona que quiera obtener la licencia tiene que cumplir estas reglas, pero cómo lo haga dependerá de sus habilidades personales. En Swift, un protocolo define estos "requisitos" y cualquier tipo que lo adopte debe implementar esos métodos o propiedades de alguna forma.
*/

//: ## Definición de Protocolos
//: `MiProtocolo` define una variable y un método que deben ser implementados por cualquier tipo que adopte este protocolo.
protocol MiProtocolo {
    var variable: Int { get }
    func algo(argumento: Int)
}

//: ## Herencia de Protocolos
//: Un protocolo puede heredar de otro. `MiProtocolo2` hereda de `MiProtocolo` y agrega un nuevo método `algo2()`.
protocol MiProtocolo2: MiProtocolo {
    func algo2()
}

//: ## Implementación de Protocolos en una Estructura
//: `MiStruct` adopta `MiProtocolo2`, por lo tanto, debe implementar todos los métodos y propiedades requeridas tanto por `MiProtocolo` como por `MiProtocolo2`.
struct MiStruct: MiProtocolo2 {
    var variable: Int
    func algo(argumento: Int) {
        // Implementación del método algo
    }
    func algo2() {
        // Implementación del método algo2
    }
}

//: ## Implementación de Protocolos en una Clase
//: `MiClase` y `MiClase2` adoptan `MiProtocolo`. Cada clase implementa el método `algo(argumento:)` de una forma diferente.
final class MiClase: MiProtocolo {
    let variable: Int
    
    init(variable: Int) {
        self.variable = variable
    }
    
    func algo(argumento: Int) {
        print(argumento, variable)
    }
}

final class MiClase2: MiProtocolo {
    let variable: Int
    
    init(variable: Int) {
        self.variable = variable
    }
    
    func algo(argumento: Int) {
        print("El número es \(argumento + variable)")
    }
}

let mi1 = MiClase(variable: 1)
let mi2 = MiClase2(variable: 10)

//: ## Ejemplos de Uso
//: Llamamos al método `algo(argumento:)` en dos instancias diferentes, demostrando que la implementación puede variar según la clase que adopta el protocolo.
mi1.algo(argumento: 5)
mi2.algo(argumento: 5)

//: ## Protocolo CustomStringConvertible
//: `CustomStringConvertible` es un protocolo de la librería estándar que requiere que se implemente una propiedad `description` para proporcionar una representación textual de la instancia.
struct Bicho: CustomStringConvertible {
    var description: String {
        "\(nombre) de color \(color)"
    }
    
    let nombre: String
    let color: String
}

let b1 = Bicho(nombre: "Gamusino", color: "Verde")
let b2 = Bicho(nombre: "Minion", color: "Amarillo")

//: Imprimimos los objetos `Bicho` usando `print()`, que invoca la propiedad `description` definida por `CustomStringConvertible`.
print(b1)
print("El primer bicho es \(b2)")

//: ## Protocolo Identifiable y Hashable
//: `Identifiable` y `Hashable` son dos protocolos comunes en Swift. `Identifiable` permite identificar de forma única a una instancia, mientras que `Hashable` permite utilizar la instancia en colecciones como `Set` o como clave en un `Dictionary`.
struct Empleados: Identifiable, Hashable {
    var id: Int
    let nombre: String
    let email: String
}

let emp1 = Empleados(id: 1, nombre: "Juan", email: "juan@gmail.com")
let emp2 = Empleados(id: 2, nombre: "Paco", email: "paco@gmail.com")
let emp3 = Empleados(id: 1, nombre: "Juan", email: "juan@gmail.com")

//: ## Comparación y Hash de Empleados
//: Comparamos dos instancias de `Empleados` y calculamos sus valores hash para ver cómo se comporta el protocolo `Hashable`.
emp1 == emp3
emp1.hashValue
emp2.hashValue
emp3.hashValue

/*:
# Explicación de Protocolos

- **Protocolos**: Un protocolo es un conjunto de métodos y propiedades que definen una capacidad o un comportamiento. Permiten programar orientado a interfaces, facilitando el desacoplamiento y la flexibilidad del código.
- **Adopción de Protocolos**: Una clase, estructura o enumeración puede adoptar uno o más protocolos y, al hacerlo, se compromete a implementar sus requisitos.
- **Ejemplos del Mundo Real**: Imagina un "contrato" o un "manual de instrucciones" que debes seguir para que tu objeto sea aceptado dentro de un sistema más amplio. Los protocolos funcionan de manera similar: te dicen qué deberías poder hacer, sin especificar cómo deberías hacerlo.
- **Herencia de Protocolos**: Un protocolo puede heredar de otro, lo cual permite extender su funcionalidad. Esto es similar a la herencia de clases, pero aplicado a contratos de comportamiento.
- **Protocolos de la Biblioteca Estándar**: Protocolos como `CustomStringConvertible`, `Identifiable` y `Hashable` nos permiten integrar nuestras estructuras y clases con las funcionalidades de Swift de una manera más natural y poderosa.

Los protocolos son una herramienta esencial para estructurar y organizar nuestro código, permitiendo flexibilidad y reutilización, lo cual es fundamental para escribir código limpio y mantenible.
*/
