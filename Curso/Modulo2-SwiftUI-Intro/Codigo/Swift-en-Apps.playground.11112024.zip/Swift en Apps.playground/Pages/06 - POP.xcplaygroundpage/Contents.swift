import Foundation

/*:
# Programación Orientada a Protocolos en Swift

La **Programación Orientada a Protocolos (POP)** es un paradigma que hace uso de los **protocolos** para definir comportamiento en lugar de una jerarquía de herencia como en la programación orientada a objetos (POO). Este enfoque permite escribir código más modular y reutilizable, ya que los **protocolos** pueden ser combinados para crear distintos comportamientos sin la necesidad de una jerarquía compleja.

### Ventajas de la Programación Orientada a Protocolos
1. **Flexibilidad**: A diferencia de la herencia, las structs, clases y enums pueden **conformar múltiples protocolos**, permitiendo construir componentes reutilizables y flexibles sin estar atados a una única jerarquía.
2. **Composición sobre Herencia**: En lugar de utilizar la herencia para extender funcionalidades, los protocolos permiten **componer comportamientos**. Es decir, podemos agregar solo las capacidades que necesitamos sin tener que heredar propiedades innecesarias.
3. **Modularidad**: Los protocolos junto con las **extensiones** permiten implementar métodos por defecto, haciendo el código mucho más **modular** y fácil de mantener. Podemos extender cualquier protocolo para agregar funcionalidad sin tener que modificar las structs o clases que los adoptan.

En este ejemplo, construiremos una jerarquía de personajes usando la orientación a protocolos, en lugar de herencia, y veremos cómo podemos **combinar protocolos** para crear personajes únicos.

### Ejemplo del Mundo Real
Imagina que estás construyendo juguetes de **LEGO**. Cada pieza tiene una función específica: algunos bloques tienen ruedas, otros tienen puertas, y otros tienen luces. Puedes combinar estas piezas para hacer un coche, un edificio o un robot, dependiendo de qué propiedades quieras agregar. Los **protocolos** son similares, ya que puedes combinarlos para construir algo único sin estar limitado por una estructura jerárquica fija.
*/

//: ## Protocolos y Extensiones
//: Creamos varios **protocolos** que definen propiedades y comportamientos comunes que los personajes pueden tener.

//: ### Protocolo `Personaje`
protocol Personaje {
    //: `nombre` es la propiedad que define un personaje. Es de lectura y escritura.
    var nombre: String { get set }
}

//: ### Protocolo `Mortal`
protocol Mortal {
    var vida: Int { get set }
    var muerto: Bool { get }
}

//: ### Extensión del Protocolo `Mortal`
//: Usamos una extensión para agregar una implementación por defecto a la propiedad `muerto`.
extension Mortal {
    var muerto: Bool {
        vida <= 0
    }
}

//: ### Protocolo `Hablador`
protocol Hablador {
    var dialogo: String { get set }
    func hablar()
}

//: ### Extensión del Protocolo `Hablador`
//: Agregamos una implementación por defecto para el método `hablar`, que imprime el diálogo del personaje.
extension Hablador {
    func hablar() {
        print(dialogo)
    }
}

//: ### Protocolo `Atacante`
protocol Atacante {
    var ataque: Int { get }
    func atacar() -> Int
}

//: ### Extensión del Protocolo `Atacante`
//: Definimos un comportamiento por defecto para el ataque, que devuelve un valor aleatorio entre la mitad del ataque y el ataque completo.
extension Atacante {
    func atacar() -> Int {
        Int.random(in: ataque / 2 ... ataque)
    }
}

//: ### Enumeración `Arma`
//: Definimos un tipo `Arma` que contiene distintas armas y sus respectivos poderes de ataque.
enum Arma: Int {
    case espada = 2
    case arco = 3
    case lanza = 4
}

//: ### Protocolo `Armado`
//: `Armado` hereda del protocolo `Atacante` y agrega una propiedad `arma`.
protocol Armado: Atacante {
    var arma: Arma { get }
}

//: ### Extensión del Protocolo `Armado`
//: Sobreescribimos el método `atacar` para agregar el valor del arma al poder de ataque.
extension Armado {
    func atacar() -> Int {
        Int.random(in: ataque / 2 ... ataque) + arma.rawValue
    }
}

//: ## Implementación de Personajes Usando Protocolos

//: ### `Tendero` Conforma el Protocolo `Personaje`
struct Tendero: Personaje {
    var nombre: String
}

//: ### `OgroBorracho` Conforma el Protocolo `Mortal`
struct OgroBorracho: Mortal {
    var vida = 10
}

//: ### `Gallina` Conforma el Protocolo `Atacante`
struct Gallina: Atacante {
    var ataque = 10
}

//: ### `Soldado` Conforma Varios Protocolos
//: `Soldado` conforma los protocolos `Personaje`, `Mortal`, `Hablador` y `Armado`.
struct Soldado: Personaje, Mortal, Hablador, Armado {
    var nombre: String
    var vida: Int
    var dialogo: String
    var arma: Arma
    var ataque: Int
}

//: ### `Monje` Conforma `Personaje` y `Hablador`
struct Monje: Personaje, Hablador {
    var nombre: String
    var dialogo: String
}

//: ### `Enemigo` Conforma `Personaje`, `Mortal` y `Atacante`
struct Enemigo: Personaje, Mortal, Atacante {
    var nombre: String
    var vida: Int
    var ataque: Int
}

/*:
# Conclusión sobre la Programación Orientada a Protocolos

En este ejemplo, hemos utilizado la **composición de protocolos** para crear distintos tipos de personajes con diferentes habilidades, sin la necesidad de crear jerarquías complejas de clases. La orientación a protocolos permite:

- **Crear Componentes Reutilizables**: Podemos agregar solo los comportamientos necesarios a cada personaje.
- **Modularidad**: Los protocolos junto con las extensiones hacen que el código sea más modular y fácil de mantener.
- **Flexibilidad**: Al no estar limitados por una jerarquía fija, podemos combinar los protocolos como nos convenga, adaptándonos mejor a los cambios en los requisitos.

Comparado con la herencia, la orientación a protocolos ofrece un enfoque mucho más **flexible y escalable**, permitiendo construir estructuras claras y eficientes sin el acoplamiento fuerte y la complejidad inherente a las jerarquías de clases.
*/
