import Foundation

/*:
# Formato JSON en Swift

**JSON (JavaScript Object Notation)** es un formato ligero para el intercambio de datos. Se usa ampliamente en aplicaciones modernas, especialmente para la comunicación entre servidores y clientes. JSON es sencillo, fácil de leer y escribir para los humanos, y fácil de interpretar y generar para las máquinas.

### Estructura de un Documento JSON
JSON representa datos en una estructura que utiliza pares clave-valor y listas ordenadas de valores. Los principales elementos de un JSON son:

- **Objetos**: Representan colecciones de pares clave-valor. En JSON, un objeto se representa con llaves `{}`. Por ejemplo:
  ```json
  {
    "nombre": "Juan",
    "edad": 30
  }
  ```
  Este objeto tiene dos campos: `nombre` y `edad`.

- **Arrays**: Representan listas ordenadas de valores. Un arreglo se representa con corchetes `[]`. Por ejemplo:
  ```json
  [
    "manzana",
    "banana",
    "cereza"
  ]
  ```

- **Valores**: Pueden ser de varios tipos: **cadena** (string), **número** (number), **booleano** (true o false), **nulo** (null), **objeto**, o **arreglo**. Por ejemplo:
  ```json
  {
    "activo": true,
    "saldo": null
  }
  ```

### Interoperabilidad y Uso en Aplicaciones
JSON se usa comúnmente en aplicaciones para el intercambio de información debido a su naturaleza simple y a la facilidad con la que puede ser generado o consumido por diversos lenguajes de programación. En Swift, usamos `Codable` para convertir datos entre JSON y estructuras nativas de Swift, haciendo que el proceso sea limpio y seguro.
*/

//: ## Ejemplo de Decodificación de un JSON
let json = """
{
  "departamento": 8,
  "nombre_dpto": "Ventas",
  "director": "Juan Rodríguez",
  "empleados": [
    {
      "nombre": "Pedro"
    }, {
      "nombre": "Jacinto",
      "apellido": "Benavente"
    }
  ]
}
""".data(using: .utf8)!

//: ## Definición de las Estructuras para Decodificar el JSON
//: Usamos `Codable` para que nuestras estructuras puedan ser decodificadas del JSON o codificadas a JSON.
struct Departamento: Codable {
    let departamento: Int
    let nombreDpto: String
    let director: String
    let empleados: [Empleado]
}

struct Empleado: Codable {
    let nombre: String
    let apellido: String?
}

//: ## Decodificación del JSON
//: Intentamos decodificar el JSON en una instancia de `Departamento` utilizando `JSONDecoder`.
do {
    let decoder = JSONDecoder()
    //: Usamos `.convertFromSnakeCase` para convertir claves de estilo `snake_case` a `camelCase` en Swift.
    decoder.keyDecodingStrategy = .convertFromSnakeCase
    let dpto = try decoder.decode(Departamento.self, from: json)
    dump(dpto)
} catch {
    //: Si ocurre un error, lo imprimimos para ver qué ha sucedido.
    print(error)
}

//: ## Decodificación con `try?`
//: Podemos usar `try?` para intentar decodificar sin tener que manejar errores con `do-catch`. Esto devolverá `nil` si algo falla.
let decoder = JSONDecoder()
decoder.keyDecodingStrategy = .convertFromSnakeCase
let dato = try? decoder.decode(Departamento.self, from: json)

/*:
# Resumen sobre JSON y Swift

- **Codable**: En Swift, `Codable` es un protocolo que combina `Encodable` y `Decodable`, permitiendo que estructuras y clases puedan ser convertidas desde y hacia JSON fácilmente.
- **`JSONDecoder` y `JSONEncoder`**: Swift proporciona estas clases para convertir entre JSON y estructuras/clases de Swift. En este ejemplo, hemos utilizado `JSONDecoder` para decodificar un JSON en una instancia de `Departamento`.
- **`keyDecodingStrategy`**: Configurar `JSONDecoder` con `.convertFromSnakeCase` es una forma de trabajar con JSONs cuyos nombres de clave están en `snake_case`, permitiendo que el código Swift siga la convención `camelCase`.
- **Errores de Decodificación**: Siempre es importante manejar errores al trabajar con datos externos. En este ejemplo, hemos utilizado `do-catch` para asegurarnos de capturar cualquier error que ocurra durante la decodificación.

El uso de JSON en Swift es esencial para crear aplicaciones que interactúen con APIs o bases de datos, permitiendo que los datos se transmitan y almacenen de una forma ligera y estándar.
*/
