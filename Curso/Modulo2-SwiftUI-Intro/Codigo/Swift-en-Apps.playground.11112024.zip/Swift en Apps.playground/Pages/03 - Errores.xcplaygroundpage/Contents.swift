import Foundation

/*:
# Gestión de Errores en Swift

Swift ofrece potentes herramientas para manejar errores y prevenir comportamientos inesperados durante la ejecución de programas. La **gestión de errores** permite manejar situaciones que podrían fallar, como la falta de datos, problemas de conexión o errores al acceder a recursos.

Swift utiliza una combinación de `throws`, `try`, `catch`, y `do` para manejar estos errores.
- **`throws`**: Indica que una función puede lanzar un error.
- **`throw`**: Lanza un error.
- **`try`**: Se usa para intentar ejecutar una función que puede lanzar un error.
- **`catch`**: Captura y maneja el error lanzado.

Swift maneja errores de una forma que se asemeja a las excepciones en otros lenguajes, pero con un enfoque más seguro y controlado.

### Ejemplo de la vida real
Piensa en **pedir un libro en una biblioteca**. Puede que no haya libros disponibles (cadena vacía), puede que el libro solicitado no exista (subcadena no encontrada) o puede que hayas olvidado especificar el libro que deseas (subcadena vacía). Swift te permite manejar estos casos de una manera clara y precisa para que sepas exactamente cuándo algo va mal y por qué.
*/

//: ## Funciones para Extraer Subcadenas
//: La función `extractSubstring` intenta encontrar una subcadena dentro de una cadena dada y devolverla.
func extractSubstring(_ string: String, sub: String) -> String? {
    guard !string.isEmpty,
          let range = string.range(of: sub) else { return nil }
    return String(string[range])
}

let frase1 = "One ring to rule them all"
let frase2 = "A long time ago in a galaxy far far away"

//: ### Ejemplo de Uso de `extractSubstring`
extractSubstring(frase1, sub: "ring")
extractSubstring(frase1, sub: "space")
extractSubstring(frase2, sub: "galaxy")
extractSubstring(frase2, sub: "")
extractSubstring("", sub: "rule")

//: ## Enumeración de Errores Personalizados
//: Definimos una enumeración `ErroresCadena` que representa los posibles errores al extraer una subcadena.
enum ErroresCadena: Error, LocalizedError {
    case cadenaVacia
    case stringNoEncontrado
    case subVacio
    
    var errorDescription: String? {
        switch self {
            case .cadenaVacia:
                "La cadena es vacía."
            case .stringNoEncontrado:
                "No se ha encontrado la subcadena"
            case .subVacio:
                "La subcadena es vacía"
        }
    }
}

//: ## Funciones que Lanzan Errores (`throws`)
//: La función `extractSubstringThrowing` lanza un error si la cadena está vacía, la subcadena está vacía, o la subcadena no se encuentra.
func extractSubstringThrowing(_ string: String, sub: String) throws -> String {
    guard !string.isEmpty else { throw ErroresCadena.cadenaVacia }
    guard !sub.isEmpty else { throw ErroresCadena.subVacio }
    guard let range = string.range(of: sub) else { throw ErroresCadena.stringNoEncontrado }
    return String(string[range])
}

//: ## Manejo de Errores con `do-try-catch`
//: Intentamos extraer una subcadena y, si se lanza un error, lo capturamos y lo manejamos.
do {
    try extractSubstringThrowing(frase1, sub: "ring")
} catch {
    print(error.localizedDescription)
}

do {
    try extractSubstringThrowing(frase1, sub: "space")
} catch ErroresCadena.cadenaVacia {
    print("Cadena vacía")
} catch ErroresCadena.subVacio {
    print("Substring vacía")
} catch ErroresCadena.stringNoEncontrado {
    print("Substring no encontrado")
} catch {
    print(error)
}

do {
    try extractSubstringThrowing(frase2, sub: "galaxy")
} catch let miError as ErroresCadena {
    switch miError {
        case .cadenaVacia:
            print("Cadena vacía")
        case .subVacio:
            print("Substring vacía")
        case .stringNoEncontrado:
            print("Substring no encontrado")
    }
} catch {
    print(error)
}

//: ## `throws` Anotados con el Tipo de Error en Swift 6
func extractSubstringThrowing6(_ string: String, sub: String) throws(ErroresCadena) -> String {
    guard !string.isEmpty else { throw .cadenaVacia }
    guard !sub.isEmpty else { throw .subVacio }
    guard let range = string.range(of: sub) else { throw .stringNoEncontrado }
    return String(string[range])
}

do {
    let dato = try extractSubstringThrowing6(frase2, sub: "")
    print(dato)
} catch {
    print(error.localizedDescription)
}

do {
    try extractSubstringThrowing6("", sub: "rule")
} catch {
    print(error.localizedDescription)
}

//: ## Usando `try?` para Ignorar Errores
//: `try?` nos permite intentar ejecutar una función que lanza errores y, si ocurre un error, simplemente devuelve `nil`.
try? extractSubstringThrowing6("", sub: "rule")

/*:
# Resumen sobre la Gestión de Errores

- **Enumeración de Errores**: Nos permite definir nuestros propios tipos de error que representan diferentes situaciones problemáticas en nuestra aplicación. En este ejemplo, `ErroresCadena` define tres tipos de error posibles.
- **Funciones que Lanzan Errores (`throws`)**: Al marcar una función con `throws`, indicamos que puede fallar y lanzar un error. Es necesario usar `try` cuando llamamos a estas funciones.
- **`do-try-catch`**: Utilizamos `do` para intentar ejecutar código que puede lanzar un error y `catch` para manejar los errores que se produzcan.
- **`try?`**: Esta sintaxis nos permite ejecutar código que puede lanzar errores sin necesidad de usar `do-catch`, pero convierte el resultado en un valor opcional (`nil` si hay un error).
- **Errores Localizados (`LocalizedError`)**: Implementar `LocalizedError` nos permite proporcionar descripciones claras de los errores, que luego pueden ser utilizadas en la interfaz de usuario para ayudar al usuario a comprender qué ha salido mal.

La gestión de errores es crucial para escribir código robusto y a prueba de fallos. Permite a nuestras aplicaciones comportarse de manera predecible incluso cuando se encuentran con situaciones inesperadas.
*/
