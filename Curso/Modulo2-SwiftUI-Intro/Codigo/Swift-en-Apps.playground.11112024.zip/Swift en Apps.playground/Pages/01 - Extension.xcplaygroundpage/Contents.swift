import UIKit

/*:
# Patrón de Extensiones en Swift

En Swift, las **extensiones** permiten agregar nuevas funcionalidades a un tipo existente, sin necesidad de modificar su código fuente original. Las extensiones son útiles para organizar el código, separar funcionalidades relacionadas, y extender tipos de datos de la biblioteca estándar o de terceros. Usar extensiones fomenta la reutilización y mejora la legibilidad del código, además de permitir que diferentes funcionalidades de un mismo tipo se distribuyan en diferentes bloques de código, lo cual facilita el mantenimiento.

Las extensiones no permiten agregar propiedades almacenadas a un tipo, pero sí permiten agregar **propiedades calculadas**. En este ejemplo, hemos agregado métodos y propiedades calculadas a la clase `String`.
*/

//: ## Ejemplo de Extensión de String
//: La extensión de `String` añade un método para extraer subcadenas y una propiedad calculada para contar el número de palabras.
extension String {
    //: ### Método extractSubstring(range:)
    //: Este método permite extraer una subcadena de un `String` usando un rango de índices enteros. Se asegura de que los índices estén dentro de los límites de la cadena y de que la cadena no esté vacía.
    func extractSubstring(range: Range<Int>) -> String {
        guard !isEmpty,
              range.lowerBound >= 0 else { return "" }
        if range.upperBound > count {
            let stringRange = index(startIndex, offsetBy: range.lowerBound)..<endIndex
            return String(self[stringRange])
        } else {
            let stringRange = index(startIndex, offsetBy: range.lowerBound) ..<
            index(startIndex, offsetBy: range.upperBound)
            return String(self[stringRange])
        }
    }
    
    //: ### Propiedad Calculada words
    //: Esta propiedad calculada devuelve el número de palabras que contiene la cadena. Para ello, divide el `String` usando espacios como separadores.
    var words: Int {
        components(separatedBy: " ").count
    }
}

//: ## Ejemplos de Uso
let text = "One ring to rule them all, and in the darkness bind them."

//: ### Extraer Subcadena
//: Extraemos una subcadena del texto principal entre las posiciones 7 y 13.
text.extractSubstring(range: 7 ..< 13)

//: ### Extraer Subcadena de Otro Texto
//: Probamos con otra cadena para ver la funcionalidad del método `extractSubstring`.
"En un lugar de la Mancha".extractSubstring(range: 3..<6)

//: ### Contar Palabras
//: Contamos el número de palabras en una cadena utilizando la propiedad calculada `words`.
"En un lugar de la Mancha".words
text.words

/*:
# Explicación del Patrón de Extensiones

- **Extensiones**: Nos permiten extender las funcionalidades de una clase, estructura, enumeración o protocolo ya existente. Con las extensiones, podemos agregar tanto métodos como propiedades calculadas, haciendo que nuestro código sea más modular y fácil de mantener.
- **Métodos**: En este ejemplo, hemos agregado el método `extractSubstring(range:)` para proporcionar una forma conveniente de extraer una subcadena basada en índices enteros. Este método incluye validaciones para garantizar que los índices proporcionados sean válidos.
- **Propiedades Calculadas**: Hemos agregado la propiedad calculada `words` para contar el número de palabras en un `String`. Esto demuestra cómo podemos agregar funcionalidades que serían útiles para cualquier instancia de `String` sin tener que modificar la implementación original de `String`.

Las extensiones son una forma poderosa y elegante de mejorar y extender la funcionalidad de los tipos en Swift, manteniendo un código limpio, conciso y mejor organizado.
*/
